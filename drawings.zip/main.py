from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color, Line, RoundedRectangle, Rectangle
from kivy.graphics.texture import Texture
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
import numpy as np
import os
import random
from kivy.core.audio import SoundLoader
from functools import partial
from numba import njit

# ---------------------------
# Botón redondo personalizado
# ---------------------------
class RoundButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_color = kwargs.get('background_color', (1,1,1,1))
        with self.canvas.before:
            Color(*self.background_color)
            self.rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[50])
        self.bind(pos=self.update_canvas, size=self.update_canvas)

    def update_canvas(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

    def set_color(self, color):
        self.background_color = color
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*color)
            self.rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[50])

# ---------------------------
# Flood fill animado
# ---------------------------
@njit
def flood_fill_numba(pixels, x, y, target, new_color):
    stack = [(x, y)]
    h, w = pixels.shape[:2]
    while stack:
        px, py = stack.pop()
        if 0 <= px < w and 0 <= py < h:
            if np.all(pixels[py, px] == target):
                pixels[py, px] = new_color
                stack.append((px+1, py))
                stack.append((px-1, py))
                stack.append((px, py+1))
                stack.append((px, py-1))

def flood_fill_animated(pixels, x, y, target, new_color, callback, batch=2000):
    stack = [(x, y)]
    h, w = pixels.shape[:2]

    def step(dt):
        nonlocal stack
        count = 0
        while stack and count < batch:
            px, py = stack.pop()
            if 0 <= px < w and 0 <= py < h:
                if np.all(pixels[py, px] == target):
                    pixels[py, px] = new_color
                    stack.append((px+1, py))
                    stack.append((px-1, py))
                    stack.append((px, py+1))
                    stack.append((px, py-1))
            count += 1
        callback()
        return bool(stack)

    def animate(dt):
        if step(dt):
            Clock.schedule_once(animate, 0.01)
    Clock.schedule_once(animate, 0.01)

# ---------------------------
# Widget de dibujo
# ---------------------------
class PaintWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.color = (1,0,0,1)
        self.pixels = None
        self.texture = None
        self.rect = None
        self.flood_fill_active = False

    def set_color(self, rgba):
        self.color = rgba

    def load_image(self, path):
        if os.path.exists(path):
            img = CoreImage(path)
            tex = img.texture
            self.pixels = np.frombuffer(tex.pixels, dtype=np.uint8).reshape(tex.height, tex.width, 4).copy()
            self.pixels = np.flipud(self.pixels)
            self.texture = Texture.create(size=(tex.width, tex.height))
            self.texture.blit_buffer(self.pixels.flatten(), colorfmt='rgba', bufferfmt='ubyte')
        else:
            self.pixels = np.full((400,400,4), 255, dtype=np.uint8)
            self.texture = Texture.create(size=(400,400))
            self.texture.blit_buffer(self.pixels.flatten(), colorfmt='rgba', bufferfmt='ubyte')

        self.canvas.clear()
        with self.canvas:
            self.rect = Rectangle(texture=self.texture, pos=self.pos, size=self.size)
        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        if self.rect:
            self.rect.pos = self.pos
            self.rect.size = self.size

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            x = int((touch.x - self.pos[0]) / self.size[0] * self.texture.width)
            y = int((touch.y - self.pos[1]) / self.size[1] * self.texture.height)
            if self.flood_fill_active and self.pixels is not None:
                self.flood_fill(x, y, self.color)
            with self.canvas:
                Color(*self.color)
                touch.ud['line'] = Line(points=(touch.x, touch.y), width=5)

    def on_touch_move(self, touch):
        if 'line' in touch.ud:
            touch.ud['line'].points += [touch.x, touch.y]

    def clear_canvas(self):
        if self.pixels is not None and self.texture is not None:
            self.texture.blit_buffer(self.pixels.flatten(), colorfmt='rgba', bufferfmt='ubyte')
        self.canvas.clear()
        with self.canvas:
            if self.texture:
                self.rect = Rectangle(texture=self.texture, pos=self.pos, size=self.size)

    def flood_fill(self, x, y, rgba):
        if self.pixels is None:
            return
        target_color = self.pixels[y, x].copy()
        new_color = (np.array(rgba)*255).astype(np.uint8)
        if np.array_equal(target_color, new_color):
            return
        flood_fill_animated(self.pixels, x, y, target_color, new_color, callback=self.update_texture)

    def update_texture(self):
        if self.texture:
            self.texture.blit_buffer(self.pixels.flatten(), colorfmt='rgba', bufferfmt='ubyte')
            if self.rect:
                self.rect.texture = self.texture

# ---------------------------
# Pantalla principal
# ---------------------------
class MainMenu(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = FloatLayout()
        if os.path.exists('fondo.png'):
            layout.add_widget(Image(source='fondo.png', allow_stretch=True, keep_ratio=False))
        btn_paint = RoundButton(text="Pinta y Colorea", size_hint=(0.4,0.15), pos_hint={"center_x":0.5, "center_y":0.7}, background_color=(1,0.5,0,1))
        btn_paint.bind(on_release=lambda x: setattr(self.manager, 'current', 'paint'))
        layout.add_widget(btn_paint)
        btn_games = RoundButton(text="Juegos", size_hint=(0.4,0.15), pos_hint={"center_x":0.5, "center_y":0.5}, background_color=(0,0.5,1,1))
        btn_games.bind(on_release=lambda x: setattr(self.manager, 'current', 'games'))
        layout.add_widget(btn_games)
        btn_videos = RoundButton(text="Dibujos Animados", size_hint=(0.4,0.15), pos_hint={"center_x":0.5, "center_y":0.3}, background_color=(0.5,1,0.5,1))
        btn_videos.bind(on_release=lambda x: setattr(self.manager, 'current', 'videos'))
        layout.add_widget(btn_videos)
        self.add_widget(layout)

# ---------------------------
# Pantalla Pintura
# ---------------------------
class PaintScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = FloatLayout()
        self.paint_widget = PaintWidget(size_hint=(1,0.75), pos_hint={"x":0, "y":0.15})
        layout.add_widget(self.paint_widget)

        colors = [(1,0,0,1),(0,1,0,1),(0,0,1,1),(1,1,0,1),(1,0.5,0,1),(0,1,1,1),
                  (1,0,1,1),(0.5,0.5,0.5,1),(0.3,0.2,0.1,1),(1,1,1,1),(0,0,0,1),(0.5,0,0.5,1)]
        box_top = BoxLayout(size_hint=(1,0.05), pos_hint={"y":0.9})
        box_bottom = BoxLayout(size_hint=(1,0.05), pos_hint={"y":0.85})
        for i, c in enumerate(colors):
            btn = RoundButton(background_color=c)
            btn.bind(on_release=lambda x, col=c: self.paint_widget.set_color(col))
            (box_top if i<6 else box_bottom).add_widget(btn)
        layout.add_widget(box_top)
        layout.add_widget(box_bottom)

        images_folder = 'images'
        img_files = [f for f in os.listdir(images_folder) if f.lower().endswith(('.png','.jpg','.jpeg'))]
        box_images = BoxLayout(size_hint=(1,0.1), pos_hint={"y":0.95})
        for img_file in img_files:
            btn_img = RoundButton(background_normal=os.path.join(images_folder,img_file),
                                  background_down=os.path.join(images_folder,img_file))
            btn_img.bind(on_release=lambda b, f=os.path.join(images_folder,img_file): self.load_image(f))
            box_images.add_widget(btn_img)
        layout.add_widget(box_images)

        btn_new = RoundButton(text="Nuevo Dibujo", size_hint=(0.3,0.08), pos_hint={"x":0.05, "y":0.05}, background_color=(0,1,1,1))
        btn_new.bind(on_release=lambda x: self.new_canvas())
        layout.add_widget(btn_new)
        btn_clear = RoundButton(text="Borrar", size_hint=(0.3,0.08), pos_hint={"x":0.4, "y":0.05}, background_color=(1,0,0,1))
        btn_clear.bind(on_release=lambda x: self.paint_widget.clear_canvas())
        layout.add_widget(btn_clear)
        btn_back = RoundButton(text="Volver al menú", size_hint=(0.3,0.08), pos_hint={"x":0.75, "y":0.05}, background_color=(0.2,0.2,0.2,1))
        btn_back.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        layout.add_widget(btn_back)

        self.add_widget(layout)
        if img_files:
            self.load_image(os.path.join(images_folder,img_files[0]))

    def new_canvas(self):
        self.paint_widget.pixels = np.full((400,400,4), 255, dtype=np.uint8)
        self.paint_widget.texture = Texture.create(size=(400,400))
        self.paint_widget.texture.blit_buffer(self.paint_widget.pixels.flatten(), colorfmt='rgba', bufferfmt='ubyte')
        self.paint_widget.canvas.clear()
        with self.paint_widget.canvas:
            self.paint_widget.rect = Rectangle(texture=self.paint_widget.texture, pos=self.paint_widget.pos, size=self.paint_widget.size)
        self.paint_widget.flood_fill_active = False

    def load_image(self, path):
        self.paint_widget.load_image(path)
        self.paint_widget.flood_fill_active = True

# ---------------------------
# Pantalla Juegos Simon Dice con sonido
# ---------------------------
class GamesScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = FloatLayout()
        self.add_widget(self.layout)
        self.show_main_buttons()

        # Cargar sonidos de los botones (asegúrate de tener estos archivos .wav)
        self.sounds = [
            SoundLoader.load('sounds/red.wav'),
            SoundLoader.load('sounds/green.wav'),
            SoundLoader.load('sounds/blue.wav'),
            SoundLoader.load('sounds/yellow.wav')
        ]

    def show_main_buttons(self):
        self.layout.clear_widgets()

        btn_back = RoundButton(
            text="Volver al menú",
            size_hint=(0.4,0.1),
            pos_hint={"center_x":0.5,"y":0.05},
            background_color=(0.7,0.2,0.2,1)  # rojo oscuro
        )
        btn_back.bind(on_release=lambda x: setattr(self.manager,'current','main'))
        self.layout.add_widget(btn_back)

        btn_simon = RoundButton(
            text="Simon Dice",
            size_hint=(0.4,0.1),
            pos_hint={"center_x":0.5,"y":0.7},
            background_color=(0.2,0.5,1,1)  # azul
        )
        btn_simon.bind(on_release=lambda x: self.start_simon())
        self.layout.add_widget(btn_simon)

    def start_simon(self):
        self.layout.clear_widgets()
        self.sequence = []
        self.user_sequence = []
        self.level = 1
        self.colors = [(1,0,0,1),(0,1,0,1),(0,0,1,1),(1,1,0,1)]
        self.buttons = []

        positions = [{"center_x":0.25,"center_y":0.6},
                     {"center_x":0.75,"center_y":0.6},
                     {"center_x":0.25,"center_y":0.3},
                     {"center_x":0.75,"center_y":0.3}]
        for i, col in enumerate(self.colors):
            btn = RoundButton(size_hint=(0.3,0.3), pos_hint=positions[i])
            btn.set_color(col)
            btn.bind(on_release=partial(self.press_color, i))
            self.layout.add_widget(btn)
            self.buttons.append(btn)

        # Botón volver
        btn_back = RoundButton(text="Volver", size_hint=(0.3,0.08), pos_hint={"center_x":0.5,"y":0.05})
        btn_back.bind(on_release=lambda x: self.show_main_buttons())
        self.layout.add_widget(btn_back)

        Clock.schedule_once(lambda dt: self.next_round(), 1)

    def next_round(self):
        self.user_sequence = []
        self.sequence.append(random.randint(0,3))
        self.flash_sequence(0)

    def flash_sequence(self, idx):
        if idx >= len(self.sequence):
            return
        btn_idx = self.sequence[idx]
        btn = self.buttons[btn_idx]
        original_color = btn.background_color

        # Cambiar color a blanco
        btn.set_color((1,1,1,1))

        # Reproducir sonido del botón
        if self.sounds[btn_idx]:
            self.sounds[btn_idx].play()

        Clock.schedule_once(lambda dt: self.restore_color(btn, original_color, idx), 0.5)

    def restore_color(self, btn, color, idx):
        btn.set_color(color)
        Clock.schedule_once(lambda dt: self.flash_sequence(idx+1), 0.3)

    def press_color(self, idx, instance):
        if len(self.user_sequence) >= len(self.sequence):
            return
        self.user_sequence.append(idx)
        if self.user_sequence[-1] != self.sequence[len(self.user_sequence)-1]:
            self.layout.clear_widgets()
            self.layout.add_widget(Label(text=f"Fallaste en el nivel {self.level}", font_size=32, pos_hint={"center_x":0.5,"center_y":0.5}))
            btn_back = RoundButton(text="Volver", size_hint=(0.3,0.08), pos_hint={"center_x":0.5,"y":0.05})
            btn_back.bind(on_release=lambda x: self.show_main_buttons())
            self.layout.add_widget(btn_back)
            return
        if len(self.user_sequence) == len(self.sequence):
            self.level += 1
            Clock.schedule_once(lambda dt: self.next_round(), 1)


# ---------------------------
# Pantalla Videos
# ---------------------------
class VideosScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = FloatLayout()
        btn_back = RoundButton(text="Volver al menú", size_hint=(0.4,0.1), pos_hint={"center_x":0.5,"y":0.05}, background_color=(1,0,0,1))
        btn_back.bind(on_release=lambda x: setattr(self.manager,'current','main'))
        layout.add_widget(btn_back)
        self.add_widget(layout)

# ---------------------------
# App principal
# ---------------------------
class GordinchisApp(App):
    def build(self):
        sm = ScreenManager(transition=FadeTransition(duration=0.3))
        sm.add_widget(MainMenu(name='main'))
        sm.add_widget(PaintScreen(name='paint'))
        sm.add_widget(GamesScreen(name='games'))
        sm.add_widget(VideosScreen(name='videos'))
        return sm

if __name__ == "__main__":
    GordinchisApp().run()





































